#include <iostream>

// EQ 기능을 외부에서 가져옴!
extern void ApplyEQ();

int main() {
    std::cout << "🎧 두부 LIVE EQ 부스터 시작 중..." << std::endl;

    ApplyEQ(); // 👉 이게 EQ 필터 실행 코드예요!

    std::cout << "📡 방송 사운드 울림 준비 완료!" << std::endl;
    return 0;
}