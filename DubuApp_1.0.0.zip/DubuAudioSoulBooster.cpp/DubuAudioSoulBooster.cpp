"SUCheckingForUpdates" = "업데이트 확인 중...";
"SUUpdateAvailableTitle" = "새 버전이 사용 가능합니다.";
"SUInstallButtonTitle" = "지금 설치";
"SUCancelButtonTitle" = "취소";
"SUReleaseNotesLabel" = "릴리즈 노트:";