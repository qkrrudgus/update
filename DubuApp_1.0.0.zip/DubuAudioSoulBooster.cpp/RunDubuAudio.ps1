#include <iostream>

// 내심장의 감성 EQ 적용
void ApplyEQ() {
    std::cout << "🎛 내심장 EQ 적용 중..." << std::endl;

    float gainLow  = 3.5f;  // 저음 강조
    float gainMid  = 1.0f;  // 중음 유지
    float gainHigh = 2.8f;  // 고음 선명하게

    std::cout << "🔈 EQ 설정 - Low: " << gainLow << " | Mid: " << gainMid << " | High: " << gainHigh << std::endl;
    std::cout << "✅ EQ가 감성적으로 적용되었습니다!" << std::endl;
}